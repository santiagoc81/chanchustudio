El objetivo de este proyecto es armar un sitio web de un eventual estudio de diseño donde ofrezcamos aplicaciones web a necesidad de nuestro clientes
